
当你实现 langgraph 时 ，请先深入学习一下官方的实现
https://langchain-ai.github.io/langgraph/how-tos/multi_agent/
https://langchain-ai.github.io/langgraph/concepts/multi_agent/
https://langchain-ai.github.io/langgraph/agents/multi-agent/

这个是官方的最佳实践
https://github.com/langchain-ai/open_deep_research/

工具使用 ToolNode
要有记忆模块
目录结构清晰，每个文件负责不同的职能

现在请结合当前上下文，深入分析问题，并提出专业的全局性解决方案。
**请牢记：使用中文回答 **
** 这是一个使用 uv 管理的项目**
** 代码中的注释使用中文**
